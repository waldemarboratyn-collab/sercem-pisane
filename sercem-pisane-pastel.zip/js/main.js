
const poemsUrl = 'data/poems.json';
const poemListEl = document.getElementById('poem-list');
const poemTitleEl = document.getElementById('poem-title');
const poemContentEl = document.getElementById('poem-content');
const playlistEl = document.getElementById('playlist');
const audioPlayer = document.getElementById('audio-player');
const audioSource = document.getElementById('audio-source');
const galleryGrid = document.getElementById('gallery-grid');
document.getElementById('year').textContent = new Date().getFullYear();

async function fetchPoems(){
  try{
    const res = await fetch(poemsUrl);
    const data = await res.json();
    buildPoemList(data.poems || []);
    buildGallery(data.gallery || []);
    buildPlaylist(data.audio || []);
  }catch(e){
    console.error('Błąd ładowania poems.json', e);
    const fallback = [];
    for(let i=1;i<=117;i++) fallback.push({id:i, title:`Wiersz nr ${i}`, file:`poems/${String(i).padStart(3,'0')}.txt`});
    buildPoemList(fallback);
  }
}

function buildPoemList(poems){
  poemListEl.innerHTML = '';
  poems.forEach(p => {
    const btn = document.createElement('button');
    btn.textContent = `${p.id}. ${p.title}`;
    btn.addEventListener('click',()=> showPoem(p));
    poemListEl.appendChild(btn);
  });
}

async function showPoem(p){
  poemTitleEl.textContent = `${p.id}. ${p.title}`;
  try{
    const res = await fetch(p.file);
    if(res.ok){
      const text = await res.text();
      const paragraphs = text.split('\n').map(s => `<p>${escapeHtml(s)}</p>`).join('');
      poemContentEl.innerHTML = paragraphs || '<em>Brak treści.</em>';
    } else {
      poemContentEl.innerHTML = '<em>Brak treści.</em>';
    }
  }catch(e){
    poemContentEl.innerHTML = '<em>Brak treści.</em>';
  }
}

function escapeHtml(unsafe){
  return unsafe.replace(/[&<>"']/g, function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#039;"}[m];});
}

function buildGallery(images){
  if(!images || !images.length){
    galleryGrid.innerHTML = '<p>Brak zdjęć w galerii. Dodaj pliki do assets/images i zaktualizuj data/poems.json</p>';
    return;
  }
  galleryGrid.innerHTML = '';
  images.forEach(src => {
    const div = document.createElement('div');
    div.className = 'photo';
    const img = document.createElement('img');
    img.src = `assets/images/${src}`;
    img.alt = src;
    div.appendChild(img);
    galleryGrid.appendChild(div);
  });
}

function buildPlaylist(audio){
  if(!audio || !audio.length){
    playlistEl.innerHTML = '<li>Brak plików audio.</li>';
    return;
  }
  playlistEl.innerHTML = '';
  audio.forEach((item, idx)=>{
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = '#';
    a.textContent = `${idx+1}. ${item.title || item.file}`;
    a.addEventListener('click', e => { e.preventDefault(); playTrack(item.file); });
    li.appendChild(a);
    playlistEl.appendChild(li);
  });
}

function playTrack(file){
  audioSource.src = `assets/audio/${file}`;
  audioPlayer.load();
  audioPlayer.play();
}

fetchPoems();
