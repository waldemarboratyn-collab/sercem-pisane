
# Sercem pisane — pastelowa wersja strony

Strona statyczna: pastelowy, artystyczny wygląd — gotowa do wgrania na GitHub Pages.

## Struktura
- index.html
- css/style.css
- js/main.js
- data/poems.json
- poems/001.txt ... 117.txt
- assets/images/*, assets/audio/*, assets/pdfs/*

## Jak używać
1. Rozpakuj archiwum i wgraj zawartość do repozytorium GitHub `sercem-pisane`.
2. Upewnij się, że `data/poems.json` zawiera poprawne ścieżki do plików i pliki .txt istnieją w folderze `poems/`.
3. Aby opublikować: ustaw GitHub Pages z branch `main` (lub `gh-pages`) i folder `/ (root)`.

## Edycja wierszy
Edytuj pliki `poems/001.txt` itd. aby wstawić treść wierszy. Strona je automatycznie załaduje.

